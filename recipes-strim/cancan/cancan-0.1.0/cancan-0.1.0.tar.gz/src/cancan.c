/*
 * Copyright (C) Strim.
 *
 * Author: Grommerin
 *
 *
 * Your desired license
 *  
 */

#include <stdlib.h>
#include <stdio.h>

int main(void) {
        puts("Hello World"); /* prints Hello World */
        return 0;
}
