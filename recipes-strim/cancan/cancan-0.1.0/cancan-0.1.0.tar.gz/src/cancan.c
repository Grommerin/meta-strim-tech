#include "inc/can_config.h"
#include <libsocketcan.h>
//#include "threads/threads.h"
//#include <libsocketcan.h>
//#include "can_config.h"
//#include "libsocketcan.h"

#include <errno.h>
#include <getopt.h>
#include <libgen.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <stdint.h>
#include <time.h>
#include <pthread.h>
#include <fcntl.h>         // open
#include <unistd.h>        // close
#include <mqueue.h>

#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/sendfile.h>  // sendfile
#include <sys/stat.h>

#include <linux/can.h>
#include <linux/can/raw.h>
#include <linux/can/error.h>
#include <linux/msg.h>

#define BUF_SIZ	(255)
#define MQ_MSGS_MAX 10

static int	s = -1;
static int	running = 1;

// Для очереди
mqd_t canutils;
typedef struct
{
	unsigned long ID;
	unsigned char  SE;
	unsigned char RD;
	unsigned char DLC;
	time_t sec;
	suseconds_t usec;
	unsigned char data[8];
} tSaveBuf;

void * streamdump(void * arg);

struct timeval tv;
time_t curtime;
suseconds_t curutime;
time_t zerotime;
suseconds_t zeroutime;
int tzero = 0;

char *filehead = "     TIME\t\tID\t\tRTR\tEXT\tDLC\tDATA\n";

void timezero()
{
	if (tzero == 0)
	{
		gettimeofday(&tv, NULL);
		zerotime=tv.tv_sec;
		zeroutime=tv.tv_usec;
		tzero = 1;
	}
}
void calctime()
{
	curtime = tv.tv_sec - zerotime;
	if ((curutime = tv.tv_usec - zeroutime) < 0)
	{
		curutime += 1000000;
		curtime--;
	}
}
void * streamdump(void * arg)
{
   //-------------------код потока start--------------------------//
	struct can_frame frame;
	struct ifreq ifr;
	struct sockaddr_can addr;
	int cntr=0;

	char *interface = "can0";
	char *optout = NULL;
	int family = PF_CAN, type = SOCK_RAW, proto = CAN_RAW;
	int nn = 0, err;
	int nbytes;
	uint32_t id, mask;
	int error = 0;
	tSaveBuf transmit_element;

	s = socket(family, type, proto);
	if (s < 0)
	{
		perror("socket");
		//return 1;
	}

	addr.can_family = family;
	strncpy(ifr.ifr_name, interface, sizeof(ifr.ifr_name));
	//Проверка ошибки, не знаю надо ли, но пусть пока будет. ioctl - команда управления вводом-выводом, гугл в помошь.
	if (ioctl(s, SIOCGIFINDEX, &ifr))
	{
		perror("ioctl");
		//return 1;
	}
	addr.can_ifindex = ifr.ifr_ifindex;

	if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0)
	{
		perror("bind");
		//return 1;
	}

	printf(filehead);
	while (running)
	{
		if ((nbytes = read(s, &frame, sizeof(struct can_frame))) < 0)
		{
			perror("read");
			//return 1;
		}
		else
		{
			printf("Received message %d\n",++cntr);
			if (tzero == 0) timezero();
			if (tzero == 1)
				{
					gettimeofday(&tv,NULL);
					calctime();
				}
			//n = snprintf(buf, BUF_SIZ, " %10d.%06d\t", tv.tv_sec, tv.tv_usec);
			transmit_element.sec = tv.tv_sec;
			transmit_element.usec = tv.tv_usec;
			transmit_element.ID = (frame.can_id & CAN_EFF_FLAG)?(frame.can_id&CAN_EFF_MASK):(frame.can_id&CAN_SFF_MASK);
			//n += snprintf(buf + n, BUF_SIZ - n, "0x%08x\t", transmit_element.ID);
			if (frame.can_id & CAN_EFF_FLAG)
			{
				//n += snprintf(buf + n, BUF_SIZ - n, "E\t");
				transmit_element.SE = 1;
			}
			else
			{
				transmit_element.SE = 0;
				//n += snprintf(buf + n, BUF_SIZ - n, "S\t");
			}
			transmit_element.DLC = frame.can_dlc;
			memcpy(transmit_element.data,frame.data,8);
			if (frame.can_id & CAN_RTR_FLAG)
			{
				//n += snprintf(buf + n, BUF_SIZ - n, "R\t");
				//n += snprintf(buf + n, BUF_SIZ - n, "%01d\t", frame.can_dlc);
				transmit_element.RD = 0;
			}
			else
			{
				transmit_element.RD = 1;
				//n += snprintf(buf + n, BUF_SIZ - n, "D\t");
				//n += snprintf(buf + n, BUF_SIZ - n, "%01d\t", frame.can_dlc);
				//for (i = 0; i < frame.can_dlc; i++)
				//{
				//	n += snprintf(buf + n, BUF_SIZ - n, "%02x ", frame.data[i]);
				//}
			}
			if(mq_send(canutils, (char *) (&transmit_element),sizeof(tSaveBuf), 1)  != 0 )
				perror("MQ_SEND to file");
			//printf("%s\n", buf);
		}
	}
	exit (EXIT_SUCCESS);
   //-------------------код потока end--------------------------//
}

void * streamcopylog(void * arg)
{
   //-------------------код потока start--------------------------//
FILE *logfile = NULL;
char fname[sizeof("/media/ramdisk/canstream.log")+1];
tSaveBuf received_element;
struct timeval tv1;
struct stat stat_source;
time_t fisttime;
time_t secondtime;
ssize_t messlen;
char buf[BUF_SIZ];
int n = 0, i = 0;
int packnum = 0;

int source;
int dest;
unsigned int msg_prio;

sprintf(fname, "/media/ramdisk/canstream.log");
logfile = fopen(fname, "a");
fprintf(logfile, filehead);
printf("Started file save\n");
while(1)
{
	messlen = mq_receive(canutils, (char*) (&received_element),sizeof(tSaveBuf), &msg_prio);
	if(messlen>0)
	{

			packnum++;
			n = snprintf(buf, BUF_SIZ, " %10d.%06d\t",received_element.sec, received_element.usec);
			n += snprintf(buf + n, BUF_SIZ - n, "0x%08x\t", received_element.ID);

			if (received_element.SE == 1)
			{
				n += snprintf(buf + n, BUF_SIZ - n, "E\t");
			}
			else
			{
				n += snprintf(buf + n, BUF_SIZ - n, "S\t");
			}
			if (received_element.RD  == 0)
			{
				n += snprintf(buf + n, BUF_SIZ - n, "R\t");
				n += snprintf(buf + n, BUF_SIZ - n, "%01d\t", received_element.DLC);
			}
			else
			{
				n += snprintf(buf + n, BUF_SIZ - n, "D\t");
				n += snprintf(buf + n, BUF_SIZ - n, "%01d\t", received_element.DLC);
				for (i = 0; i < received_element.DLC; i++)
				{
					n += snprintf(buf + n, BUF_SIZ - n, "%02x ", received_element.data[i]);
				}
			}
			printf("%s\n", buf);
			fprintf(logfile, "%s\n",buf);
			if (packnum == 100)
			{
				fclose(logfile);
				source = open("/media/ramdisk/canstream.log", O_RDONLY, 0);
				fstat (source, &stat_source);
				dest = open("/home/root/canstream.log", O_WRONLY | O_CREAT /*| O_TRUNC/**/, 0644);
				sendfile(dest, source, 0, stat_source.st_size);
				close(source);
				close(dest);
				logfile = fopen(fname, "a");
				packnum = 0;
				fprintf(logfile, "");
				fclose(logfile);
				logfile = fopen(fname, "a");
			}
	}

   //-------------------код потока end--------------------------//
}
fclose(logfile);
}


int main(int argc, char **argv)
{
	int err = 0;
	int DUMP;
	int id1 = 1, id2 = 2;
	pthread_t thdump, thsave;

	// Очередь сообщений //
	struct mq_attr mqattrs;
	mqattrs.mq_flags = 0;//O_NONBLOCK;
	mqattrs.mq_maxmsg = MQ_MSGS_MAX;
	mqattrs.mq_msgsize = sizeof(tSaveBuf);
	mqattrs.mq_curmsgs = 0;

	printf("File created %s\n",__DATE__);

	mq_unlink("/cansave");
	canutils = mq_open("/cansave", O_RDWR | O_CREAT, 0777, &mqattrs);
	if ( canutils == (mqd_t) (-1) )
	{
		perror("MQ_CAN_OPEN");
	}

    //-------------------Инициализация потока чтения\записи-----------------------//

    DUMP = pthread_create(&thdump, NULL, streamdump, &id1);
    if (DUMP != 0)
        printf("\n Can't create DUMP thread :[%s]", strerror(err));
    else
        printf("\n Thread DUMP created successfully\n");

    //-------------------Инициализация потока сохранения--------------------------//

    DUMP = pthread_create(&thsave, NULL, streamcopylog, &id2);
    if (DUMP = 0)
        printf("\n Can't create SAVE thread :[%s]", strerror(err));
    else
        printf("\n Thread SAVE created successfully\n");

    //----------------------------Потоки созданы----------------------------------//
    DUMP = pthread_join(thdump, NULL );
  	if ( DUMP != 0 )
  	{
    	perror("Cant join to DUMP thread");
    	return EXIT_FAILURE;
  	}
  	DUMP = pthread_join(thsave, NULL );
  	if ( DUMP != 0 )
  	{
    	perror("Cant join to SAVE thread");
    	return EXIT_FAILURE;
  	}

  	(void) mq_close(canutils);
  	(void) mq_unlink("/cansave");
    return 0;

}
